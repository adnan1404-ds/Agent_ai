class Observability:
    def log(self, message):
        print(f"[LOG] {message}")
